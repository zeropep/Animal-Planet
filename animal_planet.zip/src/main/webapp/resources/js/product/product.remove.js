document.getElementById("delBtn").addEventListener("click", () => {
    e.preventDefault();
        document.querySelector("#delForm").submit();
})